package com.javatechie.spring.soap.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootSopaWsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootSopaWsApplication.class, args);
	}

}
